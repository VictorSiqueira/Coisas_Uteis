-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema manny
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema manny
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `manny` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `manny` ;

-- -----------------------------------------------------
-- Table `manny`.`CLIENTE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`CLIENTE` (
  `id_cli` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `nome` VARCHAR(100) NOT NULL COMMENT 'NOME DO CLIENTE',
  `email` VARCHAR(100) NOT NULL COMMENT 'EMAIL (LOGIN)',
  `senha` VARCHAR(8) NOT NULL COMMENT 'SENHA - COM ATE 8 CARACTERES',
  PRIMARY KEY (`id_cli`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`JOB`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`JOB` (
  `id_job` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `nome_job` VARCHAR(80) NOT NULL COMMENT 'NOME DO ARQUIVO',
  `patch_job` VARCHAR(100) NOT NULL COMMENT 'LOCALIZACAO FISICA DO ARQUIVO',
  `dat_job` DATE NOT NULL COMMENT 'DATA DE UPLOUD DO ARQUIVO',
  `status_job` CHAR(1) NOT NULL DEFAULT 'W' COMMENT 'STATUS DE PROCESSAMENTO DO ARQUIVO (W = WAIT / P = PROCESSADO) ONDE W E O DEFAULT',
  `data_proc` DATE NULL COMMENT 'DATA DE PROCESSAMENTO DO ARQUIVO',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_job`),
  INDEX `fk_JOB_CLIENTE_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_JOB_CLIENTE`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`CARGO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`CARGO` (
  `id_cargo` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_cargo`),
  INDEX `fk_CARGO_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_CARGO_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`INSTRUCAO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`INSTRUCAO` (
  `id_instrucao` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_instrucao`),
  INDEX `fk_INSTRUCAO_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_INSTRUCAO_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`SITE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`SITE` (
  `id_site` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_site`),
  INDEX `fk_SITE_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_SITE_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`ESTADO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`ESTADO` (
  `id_estado` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_estado`),
  INDEX `fk_ESTADO_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_ESTADO_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
