-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema manny
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema manny
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `manny` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `manny` ;

-- -----------------------------------------------------
-- Table `manny`.`CLIENTE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`CLIENTE` (
  `id_cli` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `nome` VARCHAR(100) NOT NULL COMMENT 'NOME DO CLIENTE',
  `email` VARCHAR(100) NOT NULL COMMENT 'EMAIL (LOGIN)',
  `senha` VARCHAR(8) NOT NULL COMMENT 'SENHA - COM ATE 8 CARACTERES',
  PRIMARY KEY (`id_cli`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`JOB`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`JOB` (
  `id_job` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `nome_job` VARCHAR(80) NOT NULL COMMENT 'NOME DO ARQUIVO',
  `patch_job` VARCHAR(100) NOT NULL COMMENT 'LOCALIZACAO FISICA DO ARQUIVO',
  `dat_job` DATE NOT NULL COMMENT 'DATA DE UPLOUD DO ARQUIVO',
  `status_job` CHAR(1) NOT NULL DEFAULT 'W' COMMENT 'STATUS DE PROCESSAMENTO DO ARQUIVO (W = WAIT / P = PROCESSADO) ONDE W E O DEFAULT',
  `data_proc` DATE NULL COMMENT 'DATA DE PROCESSAMENTO DO ARQUIVO',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_job`),
  INDEX `fk_JOB_CLIENTE_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_JOB_CLIENTE`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`CARGO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`CARGO` (
  `id_cargo` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_cargo`),
  INDEX `fk_CARGO_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_CARGO_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`INSTRUCAO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`INSTRUCAO` (
  `id_instrucao` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_instrucao`),
  INDEX `fk_INSTRUCAO_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_INSTRUCAO_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`SITE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`SITE` (
  `id_site` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_site`),
  INDEX `fk_SITE_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_SITE_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `manny`.`ESTADO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `manny`.`ESTADO` (
  `id_estado` INT NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `Descricao` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  `CLIENTE_id_cli` INT NOT NULL,
  PRIMARY KEY (`id_estado`),
  INDEX `fk_ESTADO_CLIENTE1_idx` (`CLIENTE_id_cli` ASC),
  CONSTRAINT `fk_ESTADO_CLIENTE1`
    FOREIGN KEY (`CLIENTE_id_cli`)
    REFERENCES `manny`.`CLIENTE` (`id_cli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


-- -----------------------------------------------------
-- CARGA Table `manny`.`CLIENTE`
-- -----------------------------------------------------
INSERT INTO CLIENTE (CodCli, nome, email, senha) VALUES (1,'MANNY FIAP', 'mannyfiap@gmail.com', 'fiap2015');

-- -----------------------------------------------------
-- CARGA Table `manny`.`CARGO`
-- -----------------------------------------------------
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR CREDITO I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR SERVICE DESK BILINGUE I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','TELEOPERADOR II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR SUPORTE TECNICO III');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR COBRANCA III');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR SERVICE DESK I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR VENDAS III');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car1','OPERADOR SAC III');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car2','OPERADOR SAC II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car2','OPERADOR SUPORTE TECNICO BILINGUE I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car2','OPERADOR SUPORTE TECNICO BILINGUE II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car2','OPERADOR COBRANCA II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car3','OPERADOR SUPORTE TECNICO I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car3','OPERADOR COBRANCA I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car3','OPERADOR VENDAS BILINGUE II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car3','OPERADOR VENDAS II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car3','OPERADOR SUPORTE TECNICO II');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car4','OPERADOR VENDAS I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car4','OPERADOR SAC I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car4','OPERADOR SAC BILINGUE I');
INSERT INTO CARGO (CodCli, CodCat, DescCargo) VALUES (1,'Car4','OPERADOR SAC BILINGUE II');

-- -----------------------------------------------------
-- CARGA Table `manny`.`INSTRUCAO`
-- -----------------------------------------------------
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr1','Segundo grau técnico incompleto');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr1','Superior Incompleto');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr1','Primário Incompleto');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr1','Colégio Incompleto');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr1','Ginásio Incompleto');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr2','Pós-Graduação');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr2','Ginásio Completo');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr2','Colégio Completo');
INSERT INTO INSTRUCAO (CodCli,CodCat,DescInstr) VALUES (1,'Instr2','Superior Completo');



-- -----------------------------------------------------
-- CARGA Table `manny`.`SITE`
-- -----------------------------------------------------
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','BA-FEIRA DE SANTANA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','RJ-RIO DE JANEIRO-PENHA(OP)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','ROCHAVERÁ');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','SP-BOM RETIRO(OP)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','SP-GUARULHOS(OP)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','URUGUAI');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','SP-ZONA SUL');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','CE-FORTALEZA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','CABULA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit1','RJ-NITEROI');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit2','CAMPO GRANDE');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit2','REPÚBLICA I');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit2','NOVA SÃO PAULO');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit2','SANTO ANDRÉ');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit2','LIBERDADE');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit2','SP-SAO PAULO-BARRA FUNDA(ADM)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','BELEM');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','MADUREIRA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','SANTANA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','S J CAMPOS');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','RIBEIRÃO PRETO');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','SANTOS II');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','R JANEIRO (TELEPORTO)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','MG-BELO HORIZONTE- PRADO(OP)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','S B CAMPO');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','SANTO AMARO II');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','SÃO BENTO');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit3','CAMPINAS');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','GOIÂNIA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','BOLSA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','CIDADE NOVA (RJ)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','PORTO ALEGRE');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','SALVADOR');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','CURITIBA');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','R JANEIRO (BNH)');
INSERT INTO SITE (CodCli,CodCat, DescInstr) VALUES (1,'Sit4','SANTO ANTONIO');



-- -----------------------------------------------------
-- CARGA Table `manny`.`ESTADO`
-- -----------------------------------------------------
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est1','BA');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est1','CE');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est1','PB');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est1','RN');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est1','SC');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est2','RJ');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est3','SP');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est4','MG');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est4','GO');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est4','RS');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est4','DF');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est4','MA');
INSERT INTO ESTADO (CodCli, CodCat, DescEst) VALUES (1,'Est4','PR');

COMMIT;