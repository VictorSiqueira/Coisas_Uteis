-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`CLIENTE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CLIENTE` (
  `CodCli` INT NOT NULL COMMENT 'PRIMARY KEY',
  `nome` VARCHAR(100) NOT NULL COMMENT 'NOME DO CLIENTE',
  `email` VARCHAR(100) NOT NULL COMMENT 'EMAIL (LOGIN)',
  `senha` VARCHAR(8) NOT NULL COMMENT 'SENHA - COM ATE 8 CARACTERES',
  PRIMARY KEY (`CodCli`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`JOB`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`JOB` (
  `id_job` INT NOT NULL COMMENT 'PRIMARY KEY',
  `id_cliente` INT NOT NULL COMMENT 'FOREIGN KEY REFERENCE CLIENTE',
  `nome_job` VARCHAR(80) NOT NULL COMMENT 'NOME DO ARQUIVO',
  `patch_job` VARCHAR(100) NOT NULL COMMENT 'LOCALIZACAO FISICA DO ARQUIVO',
  `data_job` DATE NOT NULL COMMENT 'DATA DE UPLOUD DO ARQUIVO',
  `status_job` CHAR(1) NOT NULL DEFAULT 'W' COMMENT 'STATUS DE PROCESSAMENTO DO ARQUIVO (W = WAIT / P = PROCESSADO) ONDE W E O DEFAULT',
  `data_proc` DATE NULL COMMENT 'DATA DE PROCESSAMENTO DO ARQUIVO',
  PRIMARY KEY (`id_job`),
  INDEX `fk_JOB_CLIENTE_idx` (`id_cliente` ASC),
  CONSTRAINT `fk_JOB_CLIENTE`
    FOREIGN KEY (`id_cliente`)
    REFERENCES `mydb`.`CLIENTE` (`CodCli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`CARGO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CARGO` (
  `CodCli` INT NOT NULL COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `DescCargo` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  PRIMARY KEY (`CodCli`),
  CONSTRAINT `fk_CARGO_CLIENTE1`
    FOREIGN KEY (`CodCli`)
    REFERENCES `mydb`.`CLIENTE` (`CodCli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`INSTRUCAO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`INSTRUCAO` (
  `CodCli` INT NOT NULL COMMENT 'PRIAMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `DescInstr` INT NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  PRIMARY KEY (`CodCli`),
  CONSTRAINT `fk_INSTRUCAO_CLIENTE1`
    FOREIGN KEY (`CodCli`)
    REFERENCES `mydb`.`CLIENTE` (`CodCli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`SITE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`SITE` (
  `CodCli` INT NOT NULL COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `DescInstr` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  INDEX `fk_SITE_CLIENTE1_idx` (`CodCli` ASC),
  PRIMARY KEY (`CodCli`),
  CONSTRAINT `fk_SITE_CLIENTE1`
    FOREIGN KEY (`CodCli`)
    REFERENCES `mydb`.`CLIENTE` (`CodCli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`ESTADO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`ESTADO` (
  `CodCli` INT NOT NULL COMMENT 'PRIMARY KEY',
  `CodCat` VARCHAR(45) NOT NULL COMMENT 'CODIGO DA CATEGORIA',
  `DescInstr` VARCHAR(80) NOT NULL COMMENT 'DESCRICAO DA CATEGORIA',
  PRIMARY KEY (`CodCli`),
  CONSTRAINT `fk_ESTADO_CLIENTE1`
    FOREIGN KEY (`CodCli`)
    REFERENCES `mydb`.`CLIENTE` (`CodCli`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
